package com.forsekany;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.MapColor;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class DeathBlock extends Block implements ModInitializer {

    public static final String MOD_ID = "death-block";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private int cooldown = 0;
    private double killRadius = 15.0; // Radius from 5 to 100

    public DeathBlock(Settings settings) {
        super(settings);
    }

    // --- BLOCK LOGIC ---
    @Override
    public void onSteppedOn(World world, BlockPos pos, BlockState state, Entity entity) {
        if (!world.isClient) {
            checkAndKillMobs(world, pos);
        }
        super.onSteppedOn(world, pos, state, entity);
    }

    private void checkAndKillMobs(World world, BlockPos pos) {
        if (cooldown > 0) {
            cooldown--;
            return;
        }

        Box searchArea = new Box(pos).expand(killRadius);
        List<LivingEntity> nearbyEntities = world.getEntitiesByClass(
            LivingEntity.class, 
            searchArea, 
            e -> !(e instanceof PlayerEntity) && e.isAlive()
        );

        if (!nearbyEntities.isEmpty()) {
            for (LivingEntity entity : nearbyEntities) {
                entity.kill(); // Kills non-player mobs instantly
            }
            cooldown = 100; // 5-second cooldown (20 ticks per sec)
        }
    }

    // --- REGISTRATION ---
    public static final DeathBlock DEATH_BLOCK_INSTANCE = new DeathBlock(
        AbstractBlock.Settings.create()
            .mapColor(MapColor.BLACK)
            .strength(4.0f)
            .luminance(state -> 15) // Emits light level 15
    );

    public static final Item DEATH_BLOCK_ITEM = new BlockItem(DEATH_BLOCK_INSTANCE, new Item.Settings());

    public static final ItemGroup DEATH_BLOCK_GROUP = FabricItemGroup.builder()
        .icon(() -> new ItemStack(DEATH_BLOCK_ITEM))
        .displayName(Text.literal("Death Block"))
        .entries((context, entries) -> entries.add(DEATH_BLOCK_ITEM))
        .build();

    @Override
    public void onInitialize() {
        LOGGER.info("Death Block Mod Initialized!");

        Registry.register(Registries.BLOCK, new Identifier(MOD_ID, "death_block"), DEATH_BLOCK_INSTANCE);
        Registry.register(Registries.ITEM, new Identifier(MOD_ID, "death_block"), DEATH_BLOCK_ITEM);
        Registry.register(Registries.ITEM_GROUP, new Identifier(MOD_ID, "death_block_tab"), DEATH_BLOCK_GROUP);
    }
}
